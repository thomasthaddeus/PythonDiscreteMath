"""30.12 LAB*: Program: Soccer team roster (Dictionaries)"""

num_pair = {}
for i in range(5):
    number = int(input(f"Enter player {i + 1}'s jersey number:\n"))
    num_pair[number] = int(input(f"Enter player {i + 1}'s rating:\n"))
    print("")

num_list = sorted(list(num_pair.keys()))
print('ROSTER')
for i in num_list:
    print(f"Jersey number: {i}, Rating: {num_pair[i]}")


def print_menu():
    """Prints the menu."""
    print("\nMENU\na - Add player\nd - Remove player\nu - Update player rating")
    print("r - Output players above a rating\no - Output roster\nq - Quit\n")
    print("Choose an option:")

def main():
    """Main function"""
    print_menu()
    usr_input = input()
    while True:
        if usr_input == "o":
            num_list = sorted(list(num_pair.keys()))
            print('ROSTER')
            counter = 0
            for i in num_list:
                print(f"Jersey number: {i}, Rating: {num_pair[i]}")
                counter += 1
                if counter > 5:
                    pass
        elif usr_input == "a":
            jersey = int(input("Enter a new player's jersey number:\n"))
            rating = int(input("Enter the player's rating:\n"))
            num_pair[jersey] = rating
        elif usr_input == "d":
            jersey = int(input("Enter a new player's jersey number:\n"))
            if num_pair.keys() == num_pair[jersey]:
                del num_pair[jersey]
        elif usr_input == "u":
            jersey = int(input("Enter a new player's jersey number:\n"))
            rating = int(input("Enter the player's rating:\n"))
            num_pair[jersey] = rating
        elif usr_input == "r":
            rating = int(input())
            print(f"\nABOVE {rating}")
            count = 0
            for i in sorted(num_pair):
                if num_pair[i] > rating:
                    print(f"Jersey number: {i}, Rating: {num_pair[i]}")
                    count += 1
        elif usr_input == "q":
            exit()


if __name__ == "__main__":
    main()
